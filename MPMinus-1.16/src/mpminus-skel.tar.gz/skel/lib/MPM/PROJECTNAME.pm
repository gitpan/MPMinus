package MPM::<!-- cgi: ProjectName -->;

=head1 NAME

MPM::<!-- cgi: ProjectName --> - <!-- cgi: ProjectName --> project

=head1 VERSION

Version <!-- cgi: ProjectVersion -->

=head1 SYNOPSIS

    use MPM::<!-- cgi: ProjectName -->;

=head1 DESCRIPTION

<!-- cgi: ProjectName --> project

=head1 HISTORY

=over 8

=item B<<!-- cgi: ProjectVersion --> / <!-- cgi: GMT -->>

Init version

=back

See C<CHANGES> file

=head1 SEE ALSO

L<MPMinus>

=head1 AUTHOR

<!-- cgi: Author --> E<lt><!-- cgi: ServerAdmin -->E<gt>

=head1 COPYRIGHT

Copyright (C) 1998-2013 D&D Corporation. All Rights Reserved

=head1 LICENSE

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

See C<LICENSE> file

=cut

use vars qw($VERSION);
our $VERSION = <!-- cgi: ProjectVersion -->;

1;
