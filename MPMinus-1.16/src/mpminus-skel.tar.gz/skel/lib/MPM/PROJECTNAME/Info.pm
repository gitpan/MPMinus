package MPM::<!-- cgi: ProjectName -->::Info;
use strict;

=head1 NAME

MPM::<!-- cgi: ProjectName -->::Info - mpminfo controller (/info.mpm)

=head1 VERSION

Version <!-- cgi: ProjectVersion -->

=head1 DESCRIPTION

System (mpminfo) controller /info.mpm

=cut

sub record {
    (
        -uri      => '/info.mpm',
        -response => sub { shift->mpminfo },
    )
}

1;
    
