package MPM::<!-- cgi: ProjectName -->::Handlers; # $Id$
use strict;

=head1 NAME

MPM::<!-- cgi: ProjectName -->::Handlers - mod_perl2 Init Handler of <!-- cgi: ProjectName -->

=head1 VERSION

Version <!-- cgi: ProjectVersion -->

=head1 SYNOPSIS

    PerlInitHandler MPM::<!-- cgi: ProjectName -->::Handlers

=head1 DESCRIPTION

mod_perl2 Init Handler

=cut

use MPMinus;

use base qw/MPMinus::BaseHandlers/;

use vars qw($VERSION);
our $VERSION = <!-- cgi: ProjectVersion -->;

sub new { bless {}, __PACKAGE__ }
sub handler {
    my $r = shift;
    my $m = MPMinus->m;
    $m->conf_init($r, __PACKAGE__);
    __PACKAGE__->Init($m);
    
    # Handlers
    $r->handler('modperl'); # modperl, perl-script
    #$r->set_handlers(PerlHeaderParserHandler => sub { __PACKAGE__->HeaderParserHandler($m) });
    $r->push_handlers(PerlAccessHandler  => sub { __PACKAGE__->AccessHandler($m) });
    #$r->set_handlers(PerlAuthenHandler => sub { __PACKAGE__->AuthenHandler($m) });
    #$r->set_handlers(PerlAuthzHandler => sub { __PACKAGE__->AuthzHandler($m) });
    $r->push_handlers(PerlTypeHandler => sub { __PACKAGE__->TypeHandler($m) });
    $r->push_handlers(PerlFixupHandler => sub { __PACKAGE__->FixupHandler($m) });
    $r->push_handlers(PerlResponseHandler => sub { __PACKAGE__->ResponseHandler($m) });
    $r->push_handlers(PerlLogHandler => sub { __PACKAGE__->LogHandler($m) });
    $r->push_handlers(PerlCleanupHandler => sub { __PACKAGE__->CleanupHandler($m) });
    
    return __PACKAGE__->InitHandler($m);  
}
sub InitHandler {
    my $pkg = shift;
    my $m = shift;

    # ... Setting Nodes ...
    # $m->set( nodename => ' ... value ... ' ) unless $m->nodename;
    
    return __PACKAGE__->SUPER::InitHandler($m);
}

1;
