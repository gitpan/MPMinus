package MPM::<!-- cgi: ProjectName -->::Index; # $Id$
use strict;

=head1 NAME

MPM::<!-- cgi: ProjectName -->::Index - Indexer of <!-- cgi: ProjectName -->

=head1 VERSION

Version <!-- cgi: ProjectVersion -->

=head1 SYNOPSIS

    mpm project <!-- cgi: ProjectName -->

=cut

use base qw/
<!-- do: Controllers -->    MPM::<!-- cgi: ProjectName -->::<!-- val: Controller -->
<!-- loop: Controllers -->/;

use vars qw($VERSION);
our $VERSION = <!-- cgi: ProjectVersion -->;
our @ISA;
sub init { my $d = shift; foreach (@ISA) { $d->set($_->record) } }
1;
